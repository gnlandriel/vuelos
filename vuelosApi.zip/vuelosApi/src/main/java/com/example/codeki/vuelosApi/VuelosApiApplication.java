package com.example.codeki.vuelosApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VuelosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VuelosApiApplication.class, args);
	}

}
